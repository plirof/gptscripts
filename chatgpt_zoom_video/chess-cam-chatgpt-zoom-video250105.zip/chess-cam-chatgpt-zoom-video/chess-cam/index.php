<?php
include "cam.html";

?>