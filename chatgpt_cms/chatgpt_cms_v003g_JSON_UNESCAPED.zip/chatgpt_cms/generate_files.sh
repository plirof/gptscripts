touch index.php
touch login.php
touch logout.php
touch editor.php
touch edit_article.php
touch delete_article.php
touch users.csv
touch 


../make_files_folder_777.sh