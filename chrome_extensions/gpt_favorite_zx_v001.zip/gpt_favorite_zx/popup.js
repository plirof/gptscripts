document.getElementById('markButton').addEventListener('click', function() {
  chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    chrome.runtime.sendMessage({ action: 'markPage', url: tabs[0].url });
  });
});

document.getElementById('exportButton').addEventListener('click', function() {
  chrome.runtime.sendMessage({ action: 'exportList' });
});
