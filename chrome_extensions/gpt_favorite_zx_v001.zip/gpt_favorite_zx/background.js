let markedPages = [];

function extractIdFromUrl(url) {
  const regex = /\/entry\/(\d+)\//;
  const match = url.match(regex);
  return match ? match[1] : null;
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.action === 'markPage') {
    const url = request.url;
    const id = extractIdFromUrl(url);
    if (id) {
      markedPages.push({ id, url });
    } else {
      console.error('Could not extract ID from the URL:', url);
    }
  } else if (request.action === 'exportList') {
    exportList(markedPages);
  }
});

function exportList(pages) {
  const htmlContent = generateHtml(pages);
  const blob = new Blob([htmlContent], { type: 'text/html' });
  const url = URL.createObjectURL(blob);

  chrome.downloads.download({
    url: url,
    filename: 'marked_pages.html',
    saveAs: true
  });
}

function generateHtml(pages) {
  let htmlContent = '<html><head><title>Marked Pages</title></head><body>';
  pages.forEach(page => {
    htmlContent += `<p><a href="${page.url}" target="_blank">${page.id}</a></p>`;
  });
  htmlContent += '</body></html>';
  return htmlContent;
}
